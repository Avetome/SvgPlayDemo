var less = {};

less.strictUnits = true;
less.javascriptEnabled = false;
